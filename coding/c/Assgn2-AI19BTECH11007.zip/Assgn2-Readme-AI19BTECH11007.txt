
To compile the program in linux run 

g++ Assgn2-RMS-AI19BTECH11007.cpp -o rms.out
g++ Assgn2-EDF-AI19BTECH11007.cpp -o edf.out

To run these program 
./rms.out
./edf.out


